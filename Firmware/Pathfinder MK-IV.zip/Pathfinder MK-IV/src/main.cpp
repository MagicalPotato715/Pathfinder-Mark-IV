#include <Arduino.h>
#include <PWMServo.h>
#include <math.h>
#include <Wire.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_BNO055.h>
#include <SPI.h>
#include <RF24.h>
#include "utils.h"
#include "Config.h"
#include "Functions.h"


void setup() {
  Serial.begin(9600);
  //Bno055 Setup

  Bno_setup();
  radiosetup();

  
}

float calc_off(float angle, int joint, int n) {
  if (joint == 0) { //coxa
    float theta = coxaOffAng[n]+coxaOffYint[n];
    return theta;
  }
  if (joint == 1) { //femur
    float theta = femurOffAng[n]+femurOffYint[n];
    return theta;
  }
  if (joint == 2) { //tibia
    float theta = tibiaOffAng[n]+tibiaOffYint[n];
    return theta;
  }
}


// // Linear interpolation between two points in 3D space 
// void moveLegLine(float x1, float y1, float z1, int steps) { 
//   float x0 = posX; 
//   float y0 = posY; 
//   float z0 = posZ; 
//   for (int i = 0; i <= steps; i++) { float t = (float)i / steps; 
//     float x = x0 + t * (x1 - x0); 
//     float y = y0 + t * (y1 - y0); 
//     float z = z0 + t * (z1 - z0); 
//     // Compute angles via inverse kinematics Angles 
//     angles = posToAngle(x, y, z); // Send angles to your servo control function 
//     moveLeg(angles.theta1, angles.theta2, angles.theta3); 
//     posX = x; 
//     posY = y; 
//     posZ = z; 
//     delay(2); // adjust for desired speed 
//   } 
// }

void loop() {
  message_receive();
  Bno_read();




}
