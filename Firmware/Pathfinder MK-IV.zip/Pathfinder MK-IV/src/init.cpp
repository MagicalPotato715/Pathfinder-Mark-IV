#include <Arduino.h>
#include <PWMServo.h>
#include <math.h>
#include <EEPROM.h>
#include "utils.h"
#include "Config.h"
#include "Functions.h"
#include <Wire.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_BNO055.h>
#include <SPI.h>
#include <RF24.h>

Vector3 posToAngle(Vector3 pos);
void setLegAngles(int leg, Vector3 angles);
void moveToPos(int leg, Vector3 pos);

Adafruit_BNO055 bno = Adafruit_BNO055(55);
RF24 radio(41, 10); // CE, CSN

struct Angles {
  float theta;
};

PWMServo coxaServos[6];
PWMServo femurServos[6];
PWMServo tibiaServos[6];

void attachServos(){
    for (int i = 0; i < 6; i++)
    {
        coxaServos[i].attach(coxaPin[i]);
        femurServos[i].attach(femurPin[i]);
        tibiaServos[i].attach(tibiaPin[i]);
    }
}

void Bno_setup(){
    Adafruit_BNO055 bno = Adafruit_BNO055(55);
    Wire2.begin();  // initializes I2C on 25/24, SDA2/SCL2
    if(!bno.begin()) {
    Serial.println("BNO055 not detected. Check wiring!");
    while(1);
  }

  Serial.println("BNO055 detected!");
}

void Bno_read(){
  sensors_event_t event; 
  bno.getEvent(&event);

  Serial.print("X: "); Serial.print(event.orientation.x);
  Serial.print(" Y: "); Serial.print( event.orientation.y);
  Serial.print(" Z: "); Serial.println(event.orientation.z);
}

void radiosetup(){
    RF24 radio(41, 10); // CE, CSN
    const byte address[6] = "NODE1"; //sets the channel address
    if (!radio.begin()) {
    Serial.println("radio.begin() failed — check wiring and power");
    while(1);
    }
    radio.setPALevel(RF24_PA_LOW);
    radio.openReadingPipe(1, address);
    radio.startListening();
    Serial.println("RX ready");
}

void message_receive() {
  if (radio.available()){
    Angles angles;
    radio.read(&angles, sizeof(angles));
    Serial.print("Received angle: ");
    Serial.println(angles.theta);
  }
}