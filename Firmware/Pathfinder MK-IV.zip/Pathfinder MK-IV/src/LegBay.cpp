#include <Arduino.h>
#include <PWMServo.h>
#include <math.h>
#include <EEPROM.h>
#include "utils.h"
#include "Config.h"
#include "Functions.h"

PWMServo coxaServos[6];
PWMServo femurServos[6];
PWMServo tibiaServos[6];

// 16.5, 12.2, 4.3
Vector3 posToAngle(Vector3 pos){
    float dis = Vector3(0, 0, 0).distanceTo(pos);
    if (dis > totalLegLength)
    {
        Serial.println("Position out of reach");
        return Vector3(0, 0, 0);
    }

    float x = pos.x;
    float y = pos.y;
    float z = pos.z;

    float theta1 = atan2(y, x) * (180 / PI); // base angle
    float l = sqrt(x * x + y * y);
    float l1 = l - coxaLen;
    float h = sqrt(l1 * l1 + z * z);

    float phi1 = acos(constrain((pow(h, 2) + pow(femurLen, 2) - pow(tibiaLen, 2)) / (2 * h * femurLen), -1, 1)); //beta
    float phi2 = atan2(z, l1); //alpha
    float theta2 = (phi1 + phi2) * 180 / PI;
    float phi3 = acos(constrain((pow(femurLen, 2) + pow(tibiaLen, 2) - pow(h, 2)) / (2 * femurLen * tibiaLen), -1, 1));
    float theta3 = (phi3 * 180 / PI);

    return Vector3(
        theta1 + COXA_BASE_OFFSET, // tibia
        theta2 + FEMUR_BASE_OFFSET,      // femur
        180 - theta3 + TIBIA_BASE_OFFSET // coxa
    );
}

void setLegAngles(int leg, Vector3 angles) {
    coxaServos[leg].write(angles.x*coxaOffAng[leg]+coxaOffYint[leg]);
    femurServos[leg].write(angles.y*femurOffAng[leg]+femurOffYint[leg]);
    tibiaServos[leg].write(angles.z*tibiaOffAng[leg]+tibiaOffYint[leg]);
}

void moveToPos(int leg, Vector3 pos)
{
    // hex_sensor_data.xPositions[leg] = (int)pos.x;
    // hex_sensor_data.yPositions[leg] = (int)pos.y;
    // currentLegPositions[leg] = pos;

    Vector3 angles = posToAngle(pos); // IK happens here
    setLegAngles(leg, angles); //offsets and servos move
}

// Linear interpolation between two points in 3D space 
void moveLegLine(int steps, int leg, Vector3 pos) { 
  float x0 = posX[leg]; 
  float y0 = posY[leg]; 
  float z0 = posZ[leg]; 
  for (int i = 0; i <= steps; i++) { 
    float t = i / steps; 
    float x = x0 + t * (x1 - x0); 
    float y = y0 + t * (y1 - y0); 
    float z = z0 + t * (z1 - z0); 
    // Compute angles via inverse kinematics Angles 
    angles = posToAngle(x, y, z); // Send angles to your servo control function 
    moveLeg(angles.theta1, angles.theta2, angles.theta3); 
    posX = x; 
    posY = y; 
    posZ = z; 
    delay(2); // adjust for desired speed 
  } 
}

void splitStepsSmall(int leg, Vector3 pos){
  float x0 = posX[leg]; 
  float y0 = posY[leg]; 
  float z0 = posZ[leg]; 

}

void splitStepsBig(int leg, Vector3 pos){
  float x0 = posX[leg]; 
  float y0 = posY[leg]; 
  float z0 = posZ[leg]; 
  for (int i = 0; i <= 12; i++){// make sure happens for all legs

  }
}

