#pragma once

#include <PWMServo.h>
#include "utils.h"
#include "Arduino.h"
#include "Functions.h"

const unsigned long loopFrequency = 200; // Hz (adjust as needed)
const unsigned long loopPeriod = 1000000 / loopFrequency; // microseconds

const int coxaPin[6] = {0, 3, 6, 33, 14, 19};
const int femurPin[6] = {1, 4, 7, 36, 15, 22};
const int tibiaPin[6] = {2, 5, 8, 37, 18, 23};

const float coxaOffAng[6] = {1.056, 1.05, 1.066, 1.0666, 1, 1};
const float coxaOffYint[6] = {-5.5, -4.25, -11, -3, 0, 0};

const float femurOffAng[6] = {1.056, 1.0878, 1.0723, 1.0777, 1, 1};
const float femurOffYint[6] = {-12.5, -8.75, -8, -7, 0, 0};

const float tibiaOffAng[6] = {1.1, 1.0778, 1.0723, 1.05, 1, 1};
const float tibiaOffYint[6] = {-5.5, -5.5, -13.75, -11.25, 0, 0};

const float coxaLen = 43;  // coxa length
const float femurLen = 122;  // femur length
const float tibiaLen = 165; // tibia length
const float totalLegLength = coxaLen + femurLen + tibiaLen;

const float COXA_BASE_OFFSET = 0;  //Idk what this means
const float FEMUR_BASE_OFFSET = -90; //Idk what this means, smth to do with angles
const float TIBIA_BASE_OFFSET = 0; //Idk what this means

const float strideMultiplier[6] = {-1, -1, -1, 1, 1, 1}; //Idk what this means
const float rotationMultiplier[6] = {1, 0, -1, 1, 0 , -1}; //Idk what this means
const float globalLegPlacementRadians[6] = { 
    120.0 * DEG_TO_RAD, // Leg 0: Front Left
    180.0 * DEG_TO_RAD, // Leg 1: Middle Left
    240.0 * DEG_TO_RAD, // Leg 2: Back Left
    300.0 * DEG_TO_RAD, // Leg 3: Back Right
    0.0   * DEG_TO_RAD, // Leg 4: Middle Right
    60.0  * DEG_TO_RAD  // Leg 5: Front Right
};

const float distanceFromCenter = 104; // Distance from center of hexapod to coxa joint
const float distanceFromHexapodBottomToFemurJoint = 40; 
const float maxDistanceFromGround = 200;
const float legLandHeight = 45; //Height the leg lifts to when stepping
const float legPlacementAngle = 60;

const float globalSpeedMult = 0.25;
const float globalRotationStrideLengthMult = 0.8;
const float globalStrafeStrideLengthMult = 0.8;
const float globalLiftHeightMult = 0.85;

const Vector3 baseLegCalibrationPosition = Vector3(0, coxaLen, femurLen + tibiaLen);

const int TIME_TO_STAND = 200;
const int TIME_TO_SLEEP = 12000;

// make sure to change these vvvvv
float posX[6] = {0,0,0,0,0,0};
float posY[6] = {0,0,0,0,0,0};
float posZ[6] = {0,0,0,0,0,0};





