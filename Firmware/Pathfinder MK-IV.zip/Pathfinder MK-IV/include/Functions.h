#include <Arduino.h>
#include <PWMServo.h>
#include <math.h>
#include <EEPROM.h>
#include "utils.h"
#include "Config.h"

Vector3 posToAngle(Vector3 pos);
void setLegAngles(int leg, Vector3 angles);
void moveToPos(int leg, Vector3 pos);
void Bno_read();
void message_receive();
void attachServos();
void radiosetup();
void Bno_setup();